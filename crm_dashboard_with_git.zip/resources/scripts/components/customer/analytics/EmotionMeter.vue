<template>
    <v-card class="px-3">
        <v-card-text>
            <v-row>
                <v-col md="12" class="pb-0">
                    <p class="app-title-small primary--text mb-0" v-text="'Sentiment status'"></p>
                    <p  class="info-value  primary--text mb-0" >
                        {{emotions.positive}}
                        <span class="app-title primary--text-small">positive</span>
                    </p>
                </v-col>
                <v-col md="12"  class="pt-0">
                    <div class="emotions-container mt-1">
                        <div v-if="style.negative > '0%'" class="emo  white--text" :style="negativeStyles">
                            <p class="mb-0 ">NEGATIVE</p>
                            <small class="mt-n2 sentiment">{{emotions.negative}}</small>
                        </div>
                        <div v-if="style.neutral > '0%'" class="emo  white--text" :style="neutralStyles">
                            <p class="mb-0 ">NEUTRAL</p>
                            <small class="mt-n2 sentiment">{{emotions.neutral}}</small>
                        </div>
                        <div v-if="style.positive > '0%'" class="emo  white--text" :style="positiveStyles">
                            <p class="mb-0 ">POSITIVE</p>
                            <small class="mt-n2 sentiment">{{emotions.positive}}</small>
                        </div>
                    </div>
                </v-col>
            </v-row>
        </v-card-text>
        <span>
<!--                    <v-card-title class="card-bg-color app-title">-->
<!--&lt;!&ndash;         <v-icon size="28" color="white">mdi-emoticon</v-icon>&ndash;&gt;-->
<!--            Engagement satisfaction-->
<!--                        &lt;!&ndash;            <span class="ml-2 title">Emotion Meter</span>&ndash;&gt;-->
<!--        </v-card-title>-->
<!--        <v-divider></v-divider>-->
<!--        <div class="emotions-container">-->
<!--            <div class="emotion">-->
<!--                <v-icon color="green" size="140">mdi-emoticon-happy-outline</v-icon>-->
<!--                <p class="app-title primary&#45;&#45;text">{{emotions.positive}}%</p>-->
<!--            </div>-->
<!--            <div class="emotion">-->
<!--                <v-icon color="yellow" size="140">mdi-emoticon-neutral-outline</v-icon>-->
<!--                <p class="app-title primary&#45;&#45;text">{{emotions.neutral}}%</p>-->
<!--            </div>-->
<!--            <div class="emotion">-->
<!--                <v-icon color="red" size="140">mdi-emoticon-sad-outline</v-icon>-->
<!--                <p class="app-title primary&#45;&#45;text">{{emotions.negative}}%</p>-->
<!--            </div>-->
<!--        </div>-->
<!--            <v-list dense class="px-4">-->
<!--                    <v-list-item>-->
<!--                        <v-list-item-avatar><v-icon color="red">mdi-emoticon-angry</v-icon></v-list-item-avatar>-->
<!--                        <v-list-item-content>-->
<!--                            <v-row>-->
<!--                                <v-col md="">-->
<!--                                    <v-list-item-title>Negative</v-list-item-title>-->
<!--                                </v-col>-->
<!--                                <v-col md="2">-->
<!--                                    <v-list-item-title>{{this.emotions.negative}}%</v-list-item-title>-->
<!--                                </v-col>-->
<!--                                <v-col md="7">-->
<!--                                    <div class="meter text-center" :style="negativeStyles">-->
<!--                                    </div>-->
<!--                                </v-col>-->
<!--                            </v-row>-->
<!--                        </v-list-item-content>-->
<!--                    </v-list-item>-->
<!--                <v-divider></v-divider>-->
<!--                    <v-list-item>-->
<!--                        <v-list-item-avatar color="gray"><v-icon>mdi-emoticon-neutral</v-icon></v-list-item-avatar>-->
<!--                        <v-list-item-content>-->
<!--                            <v-row>-->
<!--                                <v-col md="3">-->
<!--                                    <v-list-item-title>Neutral</v-list-item-title>-->
<!--                                </v-col>-->
<!--                                <v-col md="2">-->
<!--                                    <v-list-item-title>{{this.emotions.neutral}}%</v-list-item-title>-->
<!--                                </v-col>-->
<!--                                <v-col md="7">-->
<!--                                    <div class="meter text-center" :style="neutralStyles">-->
<!--                                    </div>-->
<!--                                </v-col>-->
<!--                            </v-row>-->
<!--                        </v-list-item-content>-->
<!--                    </v-list-item>-->
<!--                <v-divider></v-divider>-->
<!--                <v-list-item>-->
<!--                    <v-list-item-avatar><v-icon color="green">mdi-emoticon-excited</v-icon></v-list-item-avatar>-->
<!--                    <v-list-item-content>-->
<!--                            <v-row>-->
<!--                                <v-col md="3">-->
<!--                                    <v-list-item-title>Positive</v-list-item-title>-->
<!--                                </v-col>-->
<!--                                <v-col md="2">-->
<!--                                    <v-list-item-title>{{this.emotions.positive}}%</v-list-item-title>-->
<!--                                </v-col>-->
<!--                                <v-col md="7">-->
<!--                                    <div class="meter text-center" :style="positiveStyles">-->
<!--                                    </div>-->
<!--                                </v-col>-->
<!--                            </v-row>-->
<!--                        </v-list-item-content>-->
<!--                    </v-list-item>-->
<!--            </v-list>-->
        </span>
    </v-card>
</template>

<script>
export default {
    name: "EmotionMeter",
    props: ['sentiment'],
    data() {
        return {
            load: false,
            emotions: {
                negative: '0%',
                neutral: '0%',
                positive: '0%',
            },
            style: {
                negative: '33%',
                neutral: '33%',
                positive: '33%',
            }
        }
    },
    watch: {
        sentiment: {
            handler: function(value) {
                this.setPercentages(value);
            },
            deep: true
        },
    },
    computed: {
        negativeStyles() {
            return {backgroundColor: 'red', width: this.style.negative, borderTopLeftRadius: '5px', borderBottomLeftRadius: '5px'}
        },
        neutralStyles() {
            return {backgroundColor: 'orange', width: this.style.neutral}
        },
        positiveStyles() {
            return {backgroundColor: 'green', width: this.style.positive, borderTopRightRadius: '5px', borderBottomRightRadius: '5px'}
        },
    },
    methods: {
        setPercentages(sentiment) {
          const negative = sentiment?.negative_count || '0%';
          const neutral = sentiment?.neutral_count || '0%';
          const positive = sentiment?.positive_count || '0%';

          // const { negative = '0%', neutral = '0%', positive = '0%' } = sentiment || {};
            this.emotions = { negative, neutral, positive };
          if (sentiment.negative_count === '0%' && sentiment.neutral_count === '0%' && sentiment.positive_count === '0%') {
                this.style = { negative: '33%', neutral: '33%', positive: '33%' }
            } else {
                this.style = { negative, neutral, positive }
            }
        }
    },
    mounted() {
        setTimeout(() => this.load = true,1);
        this.setPercentages(this.sentiment);
    }
}
</script>

<style scoped>

.emotions-container {
    border-radius: 5px;
    display: flex;
    flex-direction: row;
    height: 100%;
    width: 100%;
    align-items: center
}
.emo {
  font-size: 10px;
  font-weight: 600;
    height: 35px;
    display: flex;
  align-items: center;
    flex-direction: column;
    padding-left: 5px;
    justify-content: center;
}
.sentiment {
  font-size: 13px;
  font-weight: 600;
}
.meter {
    height: 5px;
    border-radius: 20px;
    transition: width .7s
}
</style>
