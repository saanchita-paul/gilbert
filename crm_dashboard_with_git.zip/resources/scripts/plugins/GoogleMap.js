import Vue from 'vue';
import * as VueGoogleMaps from 'vue2-google-maps';

Vue.use(VueGoogleMaps, {
    load: {
        key: process.env.MIX_GOOGLE_API_KEY || 'AIzaSyAQGNZoasawOgHMn2HiYP4YcEn8-s1qGiE',
        libraries: 'places',
    },
});
